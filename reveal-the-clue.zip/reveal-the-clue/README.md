# Reveal the Clue

Mid-fidelity interaction study. See [STUDY.md](STUDY.md) for behavior and code map.

## Run
No install or build step; there are no dependencies.

- Open `index.html` in any modern browser, or
- Serve the folder: `python3 -m http.server 8000` then visit http://localhost:8000

Tap the envelope to open it. Use Reset to close it again.

## Files
- `index.html` - the complete study (HTML + CSS + JS + inline SVG)
- `STUDY.md` - description of the study and where each piece lives in the code

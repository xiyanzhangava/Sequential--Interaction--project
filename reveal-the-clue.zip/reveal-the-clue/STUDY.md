# Study: Reveal the Clue

## What it does
A low-fidelity, grayscale "tap to reveal" study. A closed envelope sits low on the screen. Tapping it opens the flap and slides a clue card up and out of the envelope, sharpening from slightly blurred as it emerges. A Reset button closes the envelope again.

## Main visual and interactive components
- **Envelope** (`#envelope`, a focusable `role="button"` group): body (`#envelope-body`), two side folds (`#fold-left`, `#fold-right`), closed flap (`#flap-closed`) and open flap (`#flap-open`, drawn behind the card).
- **Clue card** (`#clue-card`, inner group `#clue-card-inner`): a card face plus two text bars (`#clue-card-bar-1`, `#clue-card-bar-2`) that fade in as the card rises. Clipped by `#card-clip` so it never draws outside the envelope footprint.
- **Soft focus filter** (`#fuzz` / `#fuzz-blur`): blur applied to the card while it emerges.
- **Reset button** (`#reset`) and a hidden live region (`#live`).

## User actions, feedback, states, transitions
**Actions:** click/tap the envelope; focus it with Tab and press Enter or Space; click Reset.

**States** (`data-state` on `#scene`): `closed` -> `opening` -> `open`; Reset returns to `closed`.

| Moment | Feedback |
|---|---|
| Hover (pointer devices) | Envelope outline brightens |
| Press | Envelope body, folds and flap darken quickly (70 ms) and hold for at least 160 ms even on a fast tap |
| Opening, step 1 (0-500 ms) | Closed flap collapses edge-on, then the open flap swings up behind the card |
| Opening, step 2 (540-1440 ms) | Card slides up 182 units with ease-out, blur clears, text bars fade in |
| Open | Envelope stops responding (pointer disabled, `aria-disabled`); "Clue revealed" announced |
| Reset | Animation cancelled, everything returns to the closed frame immediately |

Reduced motion: the animation runs at 4x speed and color transitions are removed.

## Where things are implemented (`index.html`)
| What | Lines |
|---|---|
| All CSS (tokens, press states, hover, reset button, reduced motion) | 15-144 |
| SVG scene (filter, clip, envelope, flap, card) | 149-185 |
| Reset button and live region | 187-188 |
| Timing constants (`FLAP_MS`, `CARD_DELAY`, `CARD_MS`, `LIFT`, `MAX_BLUR`, `PRESS_MIN_MS`) | 207-217 |
| Easing helpers | 227-230 |
| State setter (`setState`) | 232 |
| Frame renderer (`draw(t)`: flap, card position, blur, bars) | 238-269 |
| Animation loop (`tick`) and trigger (`reveal`) | 271-292 |
| Press feedback (`press`, `release`) | 294-304 |
| Event wiring (pointer, click, keyboard) | 306-318 |
| Reset handler | 320-331 |

## Tunable values
`FLAP_MS` (500), `CARD_DELAY` (540), `CARD_MS` (900), `LIFT` (182), `MAX_BLUR` (2.2), `PRESS_MIN_MS` (160).

## Dependencies and assets
None. Single self-contained `index.html`: no libraries, images, fonts, audio or network requests. All art is inline SVG (grayscale).

## Notes for connecting this study into a sequence
Natural hook: the transition to `open` inside `tick()` is the "clue revealed" event, and the Reset handler is the "restart" event. State lives inside one IIFE, so a connected prototype would likely emit a callback or custom event from `tick()` when the state becomes `open`. The card content (`#clue-card-inner`) is where a different clue would be shown.

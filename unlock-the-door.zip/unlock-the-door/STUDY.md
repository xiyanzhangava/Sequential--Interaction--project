# Study: Unlock the Door

## What it does
A low-fidelity, grayscale interaction study. The user enters a 4-digit code on a wall keypad beside a heavy door. A wrong code shakes the keypad and shows an error; the correct code (`2580`, shown on a small test-code plate) unlocks the padlock indicator, turns the door handle, and swings the door open. A Reset button returns everything to the locked state.

## Main visual and interactive components
- **Door** (`<svg id="door">`): frame, door leaf (`#leaf`), panels, handle plate, lever (`#lever`), hinges.
- **Keypad** (`<svg id="keypad">`): panel, 4-slot display (`#screen`, `#slots`), OK/error icons (`#icon-ok`, `#icon-err`), padlock indicator (`#lock-indicator`, `#shackle`, `#lockbody`), and a 3x4 key grid built in JS (`#keys`).
- **Test-code plate** (`#hint`): shows the secret code for testing.
- **Reset button** (`#reset`) and a hidden live region (`#status`) for screen readers.

## User actions, feedback, states, transitions
**Actions:** tap/click a key; press a number key 0-9 on a physical keyboard; Tab to a key and press Enter/Space; click Reset.

**States** (`state` variable): `ready` -> `checking` -> `error` or `unlocked`; Reset returns to `ready`.

| Moment | Feedback |
|---|---|
| Key press | Key cap sinks 3px and darkens for ~170 ms; short low "thunk" sound |
| Digit entered | Dash in the display becomes a dot; next empty slot is highlighted |
| 4th digit | 420 ms "checking" pause, then the result |
| Wrong code | Error X icon flashes, keypad shakes (520 ms), two low thuds, "Code incorrect" announced; display clears itself after 1.4 s |
| Correct code | Screen turns light with a check icon; sequence: padlock opens (450 ms) -> handle rotates -24 deg (900 ms) -> door leaf squashes to 40% width like swinging open (1400 ms, 1.2 s ease-in-out); "Code correct. Door unlocked." announced |
| Reset | Timers cancelled, display cleared, padlock closes, handle and door tween back |

Reduced motion (`prefers-reduced-motion`): shake and flash are disabled and tweens snap instantly.

## Where things are implemented (`index.html`)
| What | Lines |
|---|---|
| All CSS (layout, key press states, display, shake/flash keyframes, reduced motion) | 15-147 |
| Responsive layout (door + keypad side by side at >= 720px, stacked below) | 63-70 |
| Door SVG markup | 152-166 |
| Keypad SVG markup | 167-183 |
| Config: `SECRET`, `LEN` | 193-194 |
| Display slot creation, `render()`, `hideSlots()`, `clearDisplay()` | ~200-292 |
| Key layout and glyphs (`GLYPH`, `LAYOUT`, key builder) | 218-244 |
| Sound (`thunk`, Web Audio) | 248 |
| Door pose tweening (`setLeaf`, `setHandle`, `tween`) | 294-310 |
| Padlock (`lockOpen`) | 311 |
| Code entry and result flow (`input`, `fail`, `success`, `reset`) | 316-367 |
| Input handlers (`press`, pointer, keyboard, Reset) | 369-397 |

## Tunable values
`SECRET` (the code), `LEN` (code length), timings inside `success()` (450 / 900 / 1400 ms), `fail()` (1400 ms clear), the 420 ms check delay in `input()`, tween end values (`-24` handle degrees, `0.4` door scale).

## Dependencies and assets
None. Single self-contained `index.html`: no libraries, images, fonts or network requests. Sounds are synthesized with the Web Audio API. All art is inline SVG (grayscale).

## Notes for connecting this study into a sequence
Natural hooks: `success()` is the "completed" event (door open at ~2.6 s after the correct code), and `reset()` is the "restart" event. The state is internal to one IIFE, so a connected prototype would likely expose a callback or custom event from `success()`.

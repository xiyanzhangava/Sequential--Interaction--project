# Study: Reveal the Mirror Clue

## What it does
A low-fidelity, grayscale "wipe to reveal" study. A fogged oval mirror hides a clue (circle, bar, triangle). The user drags a finger or mouse across the glass to wipe the fog away along their path. Once about 85% of the glass has been wiped, the remaining fog fades out and the clue is fully shown. A round Reset button restores the fog.

## Main visual and interactive components
- **Phone-sized stage** (`.stage`, max 390 x 844) with the mirror centered and Reset at the bottom.
- **Mirror** (`#mirror`): frame ellipse, hidden clue group (`#hidden-clue`), and the fog group (`#fog`) made of the foggy surface (`#mirror-surface`) plus three swipe-hint lines (`#swipe-indicators`).
- **Reveal mask** (`#fog-mask` with `#wipe-path`): the fog is white (opaque) in the mask; the wiped path is drawn black so those areas become see-through.
- **Idle cue**: a faint ring (`.ring`) pulsing outward from the frame.
- **Reset button** (`#reset`): round icon button, dimmed until the user has wiped something.
- Light and dark themes via CSS variables (follows the OS setting; `data-theme="light|dark"` on `<html>` overrides).

## User actions, feedback, states, transitions
**Actions:** press and drag across the glass (mouse or touch); click Reset.

| Moment | Feedback |
|---|---|
| Idle | Ring pulses every 3 s to hint the mirror is interactive; swipe lines hint at the gesture |
| Press (no movement) | Surface briefly darkens (~160 ms); nothing is revealed, so a tap does nothing |
| Drag (after 6 px of movement) | Fog is wiped along the path with a 52-unit round brush; only while the pointer is over the glass |
| First wipe | Ring stops pulsing; Reset becomes fully opaque |
| >= 85% wiped | `done` state: remaining fog fades out over 380 ms; cursor returns to default; mirror label becomes "Mirror, clue revealed"; further drags are ignored |
| Reset | Mask path cleared, coverage grid rebuilt, all classes cleared, back to the start |

Interaction details: pointer capture keeps a drag going outside the glass; coalesced pointer events keep fast swipes continuous; the page does not scroll while dragging (`touch-action: none`).

## Where things are implemented (`index.html`)
| What | Lines |
|---|---|
| All CSS (stage, themes, fog fade, ring animation, reset button, reduced motion) | 15-201 |
| Dark-theme variables | 35-100 |
| SVG scene: clip path, reveal mask, mirror, clue, fog | 207-246 |
| Reset button markup | 248-254 |
| Tunables: `BRUSH_R`, `DRAG_THRESHOLD_PX`, `MIN_STEP`, `DONE_AT`, `CELL` | 266-271 |
| Coverage grid (`resetCoverage`, `insideGlass`, `markCoverage`, `distToSegment`) | 282-329 |
| Pointer to SVG coordinates (`toSvg`) | 299 |
| Press feedback (`press`) | 331 |
| Wiping and completion (`wipeTo`, `finish`, `endDrag`) | 338-365 |
| Pointer handlers (`pointerdown`, `pointermove`, `pointerup/cancel`) | 367-402 |
| Reset (`reset`) | 404-416 |

## Tunable values
`BRUSH_R` (must match mask `stroke-width` of 52), `DONE_AT` (0.85), `DRAG_THRESHOLD_PX` (6), `CELL` (8, coverage resolution), fog fade duration (`#fog` transition, 380 ms).

## Dependencies and assets
None. Single self-contained `index.html`: no libraries, images, fonts, audio or network requests. All art is inline SVG (grayscale).

## Notes for connecting this study into a sequence
Natural hook: `finish()` is the "clue revealed" event and `reset()` is the "restart" event. State lives inside one IIFE, so a connected prototype would likely emit a callback or custom event from `finish()`. The clue group (`#hidden-clue`) is where a different clue would be swapped in.
